// open a single window
var win = Ti.UI.createWindow({
	backgroundColor:'white'
});

var label = Ti.UI.createLabel({width:'auto',height:'auto',text:'TiNendWeb test'});
win.add(label);

// TODO: write your module tests here
var TiNendWeb = require('com.tdtsh.TiNendWeb');
Ti.API.info("module is => " + TiNendWeb);

label.text = TiNendWeb.example();

Ti.API.info("module exampleProp is => " + TiNendWeb.exampleProp);
TiNendWeb.exampleProp = "This is a test value";

// set spotid
TiNendWeb.setSpotid(3174);

// set apikey
TiNendWeb.setApikey('c5cb8bc474345961c6e7a9778c947957ed8e1e4f');

// create admaker view
if (Ti.Platform.name == "android") {

	var proxy = TiNendWeb.createWebView({
		message: "Creating an example Proxy",
		backgroundColor: "red",
		width: 100,
		height: 100,
		top: 100,
		left: 150
	});

	proxy.printMessage("Hello world!");
	proxy.message = "Hi world!.  It's me again.";
	proxy.printMessage("Hello world!");
	win.add(proxy);
}

win.open();

